import arff
import pandas as pd
import numpy as np
import pickle
from IPython.display import display, HTML
from sklearn.preprocessing import Binarizer
from mlxtend.frequent_patterns import apriori, association_rules
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, precision_score, \
recall_score, f1_score, roc_auc_score, roc_curve, auc, \
    confusion_matrix, log_loss
from sklearn.model_selection import cross_val_score, learning_curve
import matplotlib.pyplot as plt
from sklearn.metrics import cohen_kappa_score
from matplotlib.colors import ListedColormap
from sklearn import tree
import pydotplus
import collections
import json
from sklearn.preprocessing import LabelEncoder

import numpy as np

def fixDataSet(df):
    df = df.replace('na', np.nan)   # There's a way to do this right in read_csv
    potencial_drops = df.isnull().sum().divide(df.shape[0]).sort_values(ascending=False).head(10)
    print('Top 10 biggest percentage of NaN values per attributes:')
    print(potencial_drops)              # Print nº of missing values per attribute
    print('Transforming class into bolean')
    df = df.replace({'class': {       # Specific to this dataset!
        'neg': False,
        'pos': True
    }})
    # print(df.head(5))
    return df


# Fill in NaN values
def fillNan(df, strategy):
    print('Number of missing values: ', df.isnull().sum().sum())
    print('Filling NaN with ' + strategy)
    imputer = SimpleImputer(missing_values=np.nan, strategy=strategy)      
    imputer = imputer.fit(df.iloc[:, 1:df.shape[1]])
    df.iloc[:, 1:df.shape[1]] = imputer.transform(df.iloc[:, 1:df.shape[1]])    
    print('Number of missing values: ', df.isnull().sum().sum())
    # print(df.head(5))
    return df


def ass_rules(df,outfile="pagina.html"):

    print("Starting Frequent...")
    frequent = apriori(df, min_support=0.3, use_colnames=True, max_len=50, n_jobs=32)
    #print(frequent)
    print("Starting Rules...")
    rules = association_rules(frequent, metric="lift", min_threshold=.85)
    print("Rules Complete.")
    with open(outfile, "w") as f:
        f.write(rules.to_html())

def binarize(X):
    transformer = Binarizer().fit(X)
    df = pd.DataFrame(transformer.transform(X))
    return df


def ass_colp(dataset):
    print('\n Colposcopy\n')

    csv = open('./datasets/'+str(dataset)+'.csv', 'rb')

    df = pd.read_csv(csv, na_values='na')

    lb_make = LabelEncoder()
    df_class = lb_make.fit_transform(df['consensus'])
    df = df.drop(['consensus', 'experts::0', 'experts::1', 'experts::2', 'experts::3', 'experts::4', 'experts::5'],
                 axis=1)
                 
    df = association_rules.binarize(df)

    # print(df.head(5))
    association_rules.ass_rules(df, df_class, "./output/"+str(dataset)+".html")


# Ass rules for minority class
def ass_aps_minor():
    print('\n APS Failure\n')

    csv1 = open('./datasets/aps_failure_training_set.csv', 'rb')
    csv2 = open('./datasets/aps_failure_test_set.csv', 'rb')
    df1 = pd.read_csv(csv1, na_values='na')
    df2 = pd.read_csv(csv2, na_values='na')

    frames = [df1, df2]
    df = pd.concat(frames)
    df = df[df["class"] == "pos"]

    print(df.shape)

    print(df.describe())
    df = df.dropna()

    print(df.shape)

    lb_make = LabelEncoder()
    df_class = lb_make.fit_transform(df['class'])
    df = df.drop(['class'], axis=1)

    df = association_rules.binarize(df)

    association_rules.ass_rules(df, df_class, "./output/ass_aps_drop_onlypos.html")



print('\n APS Failure\n')

options = {
    'label': 'class'
}

input_dataset = 'aps_failure_training_set_dropedCols.csv'
df = pd.read_csv('./datasets/' + input_dataset)

print('Initial datatframe ', df.shape)

y = df.loc[:, options['label']]
x = df.drop(columns=options['label'])



# Data treatment
x = (x
      .pipe(fixDataSet)
      .pipe(fillNan, strategy='median'))

# Define labels
x = binarize(x)

ass_rules(x, "./output/ass_aps.html")
ass_aps_minor()
ass_colp('green')
ass_colp('schiller')
ass_colp('hinselmann')


